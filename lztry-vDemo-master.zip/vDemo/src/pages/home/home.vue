<template>
<div class="hello">
  <home-header :city= city></home-header>
  <home-swiper :swiperList= swiper></home-swiper>
  <home-icons :iconList= iconList></home-icons>
  <home-recommend></home-recommend>
</div>
</template>

<script>
import HomeHeader from './components/header'
import HomeSwiper from './components/swiper'
import HomeIcons from './components/icons'
import HomeRecommend from './components/recommend'
import axios from 'axios'
export default{
  name: 'home',
  components: {
    HomeHeader,
    HomeSwiper,
    HomeIcons,
    HomeRecommend
  },
  data () {
  	return {
  		city: '',
  		swiper: [],
  		iconList: []
  	}
  },
  methods:{
  	getHomeInfo () {
  		axios.get('/api/index.json')
  		.then(this.succ)
  	},
  	succ (res) {
  		res = res.data
  		if(res.ret && res.data){
  			this.city = res.data.title[0].city
  			console.log(res.data.swiperList)
  			this.swiper = res.data.swiperList
  			this.iconList = res.data.iconList
  		}else{
  			alert("错误")
  		}
  	}
  },
  mounted () {
  	this.getHomeInfo();
  }
}
</script>
