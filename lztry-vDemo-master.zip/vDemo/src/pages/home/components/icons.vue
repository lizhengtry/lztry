<template>
	<div class="icons">
		<swiper :options="swiperOption" >
			<swiper-slide v-for="(page,index) of pages" :key='index'>
				<div class="icon" v-for="item of page" :key='item.id'>
					<div class="icon-container">
						<img class="img" :src='item.imgUrl'/>
					</div>
					<p class="icon-desc">{{item.desc}}</p>
				</div>
			</swiper-slide>
		</swiper>
	</div>
</template>

<script >
 export default {
 	name: "icons", 
 	props: {
 		iconList: Array
 	},
 	computed: {
 		pages () {
 			const pages= []
 			this.iconList.forEach(function(item,index){
 				const page = Math.floor(index/8)
 				if(!pages[page]){
 					pages[page] = []
 				}
 				pages[page].push(item)
 			})
 			return pages
 		}
 	},
    data() {
      return {
        swiperOption: {
          pagination: '.swiper-pagination',
          autoplay: false
        }
      }
    }
 }
</script>

<style type="text/css" lang="stylus" scoped>
.icons
   overflow: hidden
   height: 0
   padding-bottom: 50%
   .icon
     position:relative
     overflow: hidden
     width: 25%
     height: 0
     float: left
     padding-bottom: 25%
     .icon-desc
       position: absolute
       left: 0
       right: 0
       bottom: 0
       height: .44rem
       line-height: .44rem
       text-align: center
     .icon-container
       position: absolute
       top: 0
       left: 0
       right: 0 
       bottom: .44rem
       box-sizing: border-box
       padding: .1rem
       .img
        display:block
        margin: 0 auto
        height: 100%
        border-radius: .4rem
</style>