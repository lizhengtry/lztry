<template>
	<div class="swiper-content">
		<swiper :options="swiperOption">
			<!-- slides -->
			<swiper-slide v-for="item of swiperList" :key="item.id">
				<img :src="item.imgUrl" />
			</swiper-slide>
			<!-- Optional controls -->
			<div class="swiper-pagination" slot="pagination"></div>
			<!--<div class="swiper-button-prev" slot="button-prev"></div>
		    <div class="swiper-button-next" slot="button-next"></div>-->
		    <!--<div class="swiper-scrollbar"   slot="scrollbar"></div>-->
		</swiper>
	</div>
</template>

<script>
	export default {
    name: 'carrousel',
    props: {
    	swiperList: Array
    },
    data() {
      return {
        swiperOption: {
          pagination: '.swiper-pagination',
          loop: true,
          autoplay: '2000'
        }
      }
    }
  }
</script>

<style lang="stylus" scoped="scoped">
	.swiper-content >>> .swiper-pagination-bullet-active
	  background: #fff
	.swiper-content
	  overflow:hidden
	  width:100%
	  height:0
	  padding-bottom:31.25%
	  img
	    width:100%
	    height:31.2vw
</style>