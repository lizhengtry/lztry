<template>
<div class="header">
	<div class="header-left">
		<div class="iconfont back">&#xe660;</div>
	</div>
	<div class="header-input">
		<span class="iconfont">&#xe651;</span>
		输入城市景点游玩主题
	</div>
	<router-link to='/City'>
		<div class="header-right">
			{{this.city}}
			<span class="iconfont">&#xe65c;</span>
		</div>
	</router-link>
	
</div>
</template>

<script>
export default{
  name: 'homeHeader',
  props: {
  	city: String
  }
}
</script>

<style lang="stylus" type="text/css" scoped>
@import '~@/assets/styles/var.style'
.header 
  display: flex
  line-height: .86rem
  background-color:$bgc
  color:#fff
  .header-left
    width: .64rem
    float: left
    .back 
      line-height: .88rem
      text-align: center
      font-size: .45rem
  .header-input
  	flex: 1
  	background:#fff
  	height: .64rem
  	line-height: .64rem
  	margin-top: .12rem 
  	margin-left: .2rem
  	border-radius: .1rem
  	padding-left: .2rem
  	color:#ccc
  .header-right
    width: 1.24rem
    float:right
    text-align:center
    color: white
</style>