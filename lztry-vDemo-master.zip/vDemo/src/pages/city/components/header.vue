<template>
	<div class="header">
		城市选择
		<router-link to='/'>
			<div class="iconfont back">&#xe660;</div>
		</router-link>
		
	</div>
</template>

<script>
export default {
	name: 'cityHeader'
}
</script>

<style lang="stylus" scoped="scoped">
@import '~@/assets/styles/var.style'
.header
  position: relative
  overflow: hidden
  height: .86rem
  line-height: .86rem
  text-align: center
  color: white
  background: $bgc
  font-size: .4rem
  .back
    position: absolute
    top: 0
    left: 0
    width: .64rem
    text-align: center
    font-size: .4rem
    color: white
</style>