 <template>
 	<div>
 		<city-header></city-header>
 		<search></search>
 		<list :cities='cities' :hotcity='hotcity'></list>
 		<alphabet :cities='cities'></alphabet>
 	</div>
</template>

<script>
import axios from 'axios'
import cityHeader from './components/header'
import list from './components/list'
import search from './components/search'
import alphabet from './components/alphabet'
export default{
	name: 'city',
	components: {
		axios,
		cityHeader,
		list,
		search,
		alphabet
	},
	data () {
		return {
			cities: {},
			hotcity: []
		}
	},
	methods:{
		getCity () {
			axios.get('/api/city.json').then(this.getInfoSucc)
		},
		getInfoSucc (res) {
			res = res.data
	  		if(res.ret && res.data){
	  			this.cities=res.data.cities
	  			this.hotcity=res.data.hotCities
	  		}else{
	  			alert("错误")
	  		}
	  	}
	},
	mounted () {
		this.getCity()
	}
}
</script>

<style lang="stylus" scoped="scoped">
	
</style>